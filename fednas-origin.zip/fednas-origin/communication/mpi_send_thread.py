import ctypes
import logging
import threading
import time
import traceback

from mpi4py import MPI

from communication.mpi_message import MPIMessage


class MPISendThread(threading.Thread):
    def __init__(self, comm, rank, size, name, q):
        super(MPISendThread, self).__init__()
        self._stop_event = threading.Event()
        self.comm = comm
        self.rank = rank
        self.size = size
        self.name = name
        self.q = q

    def run(self):
        logging.debug("Starting " + self.name + ". Process ID = " + str(self.rank))
        while True:
            try:
                # print(f'MPISendThread q {self.q.empty()}')
                if not self.q.empty():
                    msg = self.q.get()
                    dest_id = msg.get(MPIMessage.MSG_ARG_KEY_RECEIVER)
                    print(f'MPISendThread dest {dest_id}')
                    self.comm.send(msg.to_string(), dest=dest_id)
                else:
                    time.sleep(.2)
            except Exception:
                traceback.print_exc()

    def stop(self):
        self._stop_event.set()

    def stopped(self):
        return self._stop_event.is_set()

    def get_id(self):
        # returns id of the respective thread
        if hasattr(self, '_thread_id'):
            return self._thread_id
        for id, thread in threading._active.items():
            if thread is self:
                return id

    def raise_exception(self):
        thread_id = self.get_id()
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id,
                                                         ctypes.py_object(SystemExit))
        if res > 1:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id, 0)
            print('Exception raise failure')
